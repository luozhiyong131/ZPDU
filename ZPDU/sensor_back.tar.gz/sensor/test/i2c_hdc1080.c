﻿#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>	/* for NAME_MAX */
#include <sys/ioctl.h>
#include <string.h>
#include <strings.h>	/* for strcasecmp() */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <dirent.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>

int fd;
#if 1
unsigned short i2c_read(unsigned char addr,
                        unsigned char reg,
                        int delay)
{
  int r;
	struct i2c_msg             msgs;
  struct i2c_rdwr_ioctl_data msgset;
  
  unsigned char buf[4];
  
	msgset.msgs = &msgs;
	msgset.nmsgs = 1;
	    
  buf[0] = reg;
  msgs.addr = addr;
  msgs.flags = 0;
  msgs.buf = (void *)buf;
  msgs.len = 1;

  r = ioctl(fd, I2C_RDWR, &msgset);
  if (r<0) {
printf("CCCCCCCCCCCCCCC: %d\n", r);
return 0xffff;
}
  
  if (delay) usleep(delay);
  
  msgs.addr = addr;
  msgs.flags = I2C_M_RD;
  msgs.buf = (void *)buf;
  msgs.len = 2;

  r = ioctl(fd, I2C_RDWR, &msgset);
  if (r<0)
{
printf("DDDDDDDDDDDDDDDDDDDD\n");
 return 0xffff;
}

  return buf[0]*256 + buf[1];
}
#endif

int main(int argc, char *argv[])
{
  fd=open("/dev/i2c-0", O_RDWR);
	if(fd<0)
printf("AAAAAAAAAAAAA\n");
else
printf("BBBBBBBBBBBBBBBBBB\n");

  unsigned short temp = i2c_read(0x40,0,20000);
  unsigned short hum  = i2c_read(0x40,1,20000);

  if (temp!=0xffff)
    printf("temperature: %.3f C\n",  temp * (160.0/65536.0) - 40);
  if (hum!=0xffff)
    printf("humidity:    %.3f %%RH\n",hum  * (100.0/65536.0));

    return 0;
}

scp test sysnetwork@192.168.1.244:/tmp



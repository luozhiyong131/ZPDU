scp sensor sysnetwork@192.168.1.244:/tmp


